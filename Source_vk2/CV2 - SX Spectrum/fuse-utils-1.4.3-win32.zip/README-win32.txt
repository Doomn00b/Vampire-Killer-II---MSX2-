The Fuse utilities for Windows 1.4.3
====================================

This is a binary distribution of the Fuse utilities for Windows.  For
an introduction to fuse-utils, see README.txt.  For more detailed 
documentation, read the manuals available as HTML files.

Requirements
------------

Windows 2000/XP/Vista/7/8/10.

Libraries
---------

These binaries were built with:

    audiofile 0.3.6-git-b62c902
    bzip2 1.0.6
    libgcrypt 1.8.2
    libgpg-error 1.28
    libjpeg-turbo 1.5.3
    libpng 1.6.34
    libspectrum 1.4.4
    libstdc++6 6.4.0
    win-iconv 0.0.6
    winpthreads 5.0.4
    zlib 1.2.11

See LICENSES.txt for copyright and license details.

Notes
-----

You can extend the output formats supported by fmfconv with FFmpeg:
https://ffmpeg.zeranoe.com/builds/

fmfconv is based in part on the work of the Independent JPEG Group.

Compiled by Sergio Baldoví <serbalgi@gmail.com>
1st July, 2018
